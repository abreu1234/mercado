export class Produto {
    id:number;
    ref:string;
    nome:string;
    valor:number;
    estoque:number;
}
