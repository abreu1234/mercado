import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { AppBootstrapModule } from './app-bootstrap/app-bootstrap.module';
import { RouterModule, Routes } from '@angular/router';

import { MenuComponent } from './menu/menu.component';
import { ProdutoComponent } from './produto/produto.component';
import { ProdutoAddComponent } from './produto-add/produto-add.component';
import { ProdutoService } from './produto/produto.service';

const appRoutes: Routes = [
  { path: 'produto', component: ProdutoComponent },
  { path: 'produto/add', component: ProdutoAddComponent },
  { path: 'produto/edit/:id', component: ProdutoAddComponent }
];

@NgModule({
  declarations: [
    AppComponent,
    MenuComponent,
    ProdutoComponent,
    ProdutoAddComponent
  ],
  imports: [
    RouterModule.forRoot(
      appRoutes,
      { enableTracing: false } // <-- debugging purposes only
    ),
    BrowserModule, AppBootstrapModule, FormsModule
  ],
  providers: [ProdutoService],
  bootstrap: [AppComponent]
})
export class AppModule { }
